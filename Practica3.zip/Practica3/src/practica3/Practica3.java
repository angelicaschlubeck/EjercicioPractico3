/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica3;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp
 */
public class Practica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {  
       
      
     // Numero de prodctos disponibles   
    
     
     Tienda tienda = new Tienda(3);
     String[] productos = {"Arroz","Azucar", "Pan"};
      tienda.setProductos(productos);
     
      
      
      
    
              }
     
         
      
     
    
     
     //Mostrar ventas x producto
     int[] totalesProductos = tienda.calcular_total_ventas();
        JOptionPane.showMessageDialog(null,"Total de ventas por producto:");
        for (int i = 0; i < productos.length; i++) {
            JOptionPane.showMessageDialog(null, productos[i] + ": " + totalesProductos[i]);
     
     }
        
     
       
       
       
       
     }   
  }
        
        
       
       
 
    
