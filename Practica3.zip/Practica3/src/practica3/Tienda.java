/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica3;

import java.util.Random;

/**
 *
 * @author Hp
 */
public class Tienda {
    
    
    private String[] productos;
    private int[][] ventas_semana;
    private final int Dias = 7;
    private final Random random = new Random();
    
    public Tienda(int numero_productos){ // Constructor 
        productos = new String[numero_productos];
        ventas_semana = new int [Dias][numero_productos];
       
    }
    
    public void  asignar_productos (String[] nombres){
        this.productos = nombres;
        generarVentas();
       
    }
    
    //Ventas Random
    private void generarVentas(){
        
        for (int i = 0; i < Dias; i++) {
            for (int j = 0; j< productos.length; j++){
                ventas_semana[i][j] = random.nextInt(10);
             }
            
            
        }
    
    
    }
    //Ventas por producto 
    public int[] calcular_total_ventas(){
        int[] total = new int[productos.length];
        for (int j = 0; j < productos.length ; j++) {
            for (int i = 0; i < Dias; i++) {
                total[j] += ventas_semana[i][j];
                
            }
            
        }
        return total;
   
    
    
    }
    
    public int DiaMayorVentas(){
        int maximoventas = 0; //total más alto de ventas 
        int diaMayor = 0; //Dia con mas ventas
        
        for(int i = 0; i < Dias; i++){
            int ventas_por_dia = 0;
            for (int j = 0; j < productos.length; j++){
                ventas_por_dia += ventas_semana[i][j];
               }
            
            if (ventas_por_dia > maximoventas){
                maximoventas = ventas_por_dia;
                diaMayor = i;
            }
        
        
       }
    
    return diaMayor;
    
    }
    
    public int [][] getVentasSemana(){
        return ventas_semana;
    }

    public String[] getProductos() {
        return productos;
    }

    public void setProductos(String[] productos) {
        this.productos = productos;
    }

    public int[][] getVentas_semana() {
        return ventas_semana;
    }

    public void setVentas_semana(int[][] ventas_semana) {
        this.ventas_semana = ventas_semana;
    }
    
    
}
